import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JWindow;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Team1 {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                final JDialog dialog = new JDialog();
                dialog.add(new JPanel());
                dialog.setVisible(true);
                dialog.setBounds(100,100,100,100);

                final JWindow dependentWindow = getjWindow(dialog);
                dependentWindow.setVisible(true);
                dependentWindow.setBounds(100,100,100,100);
                Timer t = new Timer(300, new ActionListener() {

                    @Override
                    public void actionPerformed(ActionEvent e) {
                        dependentWindow.setVisible(!dependentWindow.isVisible());

                    }
                });
                t.start();
            }
        });
    }
    private static JWindow getjWindow(JDialog dialog) {
        JWindow w = new JWindow(dialog);
        JPanel panel = new JPanel();
        panel.add(new JButton("button"));
        w.add(panel);
        return w;
    }
}
